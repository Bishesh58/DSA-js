# AlgoBUS Meeting #18

Date: 03/06/2021 Saturday

Question: Quick Sort | Topic: Sorting Algorithm | Difficulty: Hard

# PART.A: Prompt Understanding and Analysis

Prompt Understanding"

What info we got from the prompt?

# PART.B: Related Concept Overview

logic or method:
step#1: pick a 'pivot number'
step#2: iterate the rest of the values
compare every num smaller than'pivot'
move pointers

# PART.C: Demo: Problem Walkthrough

1st PivotNum-- Round#1:
step#1: pick the PN
when PN = 8
step#2:iterate thru the rest of array
step#3: init pointers
1.a]
Pivot = 8
LP =5
RP =3

1.b]
iterate thru the rest of the array
GOALs:
we wanna
1.] put all the smaller numbers to the left of the 'PivotNum'
2.] put all the greater numbers to the Right of the 'PivotNum'

1.c] we need a While Loop to make sure all the RightPointers >= LeftPointers

start to iterate:
Qta:
1.] is our Number at LP >PN?
currentNum = 5
LN = 5 PN=8
NO!
&&

2.]is currentNum at RP < PN?
RN = 3 PN =8
3 < 8
YES!

Decision Making: NOT swap
move LeftPointer to the right by 1

1st PN, Round#2:
[8, 5, 2, 9, 5, 6, 3]

step#1: init the pointers
PN = 8
LN = 2
RN = 3

Qta:
1.]is LeftNum > PN?
2 >8 ?
NO!
2.]is RigthtNum < PN?
3 <8?
YES!
Decision Making?
DO NOT Swap!
Action!
move leftPointer to the right by 1

1st PivotNum -- Round#3:
[8, 5, 2, 9, 5, 6, 3]
PN = 8
LN = 9
RN =3

Qta
1.] is LN > PN?
9 > 8?
YES!

2.]is RN < PN?
3 < 8?
YES!
Decision Making: SWAP
SWAP the position of RN with LN
after swap:
[8, 5, 2, 3, 5, 6, 9]

1st PivotNum -- Round#4:
[8, 5, 2, 3, 5, 6, 9]
step#1: init pointers:
PN =8
LN =3
RN = 9

Qta:
1.] is LN > PN?
3 > 8 ?
NO!
2.] is RN< PN?
9 < 8 ?
NO!

Decision Making:
DO NOT Swap!
Action!
a.] move LeftPointer to the right by 1
&&
b.] move RightPointer to the left by 1

1st PivotNum -- Round#5:
[8, 5, 2, 3, 5, 6, 9]
step#1: init pointers:
PN =8
LN =5
RN =6

Qta?
1.] is LN > PN?
5 > 8 ?
NO!
2.] is RN < PN?
6 < 8 ?
YES!

Decision Making:
DO NOT Swap
Action!
move leftPointer to the right by 1

1st PivotNum -- Round#6:
[8, 5, 2, 3, 5, 6, 9]
step#1: init pointers:
PN =8
LN =6
RN =6

Qta?
1.] is LN > PN?
6 > 8 ?
NO!
2.] is RN < PN?
6 < 8 ?
YES!

Decision Making:
DO NOT swap!
Action!
move the leftPointer to right by 1

1st PivotNum -- Round#7:
[8, 5, 2, 3, 5, 6, 9]
step#1: init pointers:
PN =8
LN =9
RN =6

Qta?
1.] is LN > PN?
9 > 8 ?
YES!
2.] is RN < PN?
6 < 8 ?
YES!

Exciting Moment!!!!!!
Decision Making:
Swap!
Action!
Swap the position of the PivotNum with rightNum
[6, 5, 2, 3, 5, 8, 9]

Accomplishments!
now:
a.] all the numbers on the left of
the 'Perfect Sort Pivot' are smaller than the PivotNum
b.] all the numbers on the right of the 'Perfect Sort Pivot" are bigger than the PivotNum

---

Now, what we are do from here?
we apply the same Quick Sort Technique to the rest

Pick 2ndPivotNum:
2nd PivotNum-- Round#1:
step#1: pick the PN
when PN = 6
step#2:iterate thru the rest of array
step#3: init pointers
1.a]
Pivot = 6
LP =5
RP =5

Qta?
1.] is LN > PN?
5 > 6?
NO!
2.] is RN < PN?
5 < 6 ?
YES!

Decision Making: NOT swap
move LeftPointer to the right by 1

2nd PN, Round#2:
[6, 5, 2, 3, 5, 8, 9]
init Pointers:
PN =6
LN=2
RN = 5

Qta?
1.] is LN > PN?
2 > 6?
NO!
2.] is RN < PN?
5 < 6 ?
YES!

Decision Making:
DO NOT Swap!
Action!
a.] move LeftPointer to the right by 1

2nd PN, Round#3:
[6, 5, 2, 3, 5, 8, 9]
init Pointers:
PN =6
LN=3
RN =5

Qta?
1.] is LN > PN?
3 > 6?
NO!
2.] is RN < PN?
5 < 6 ?
YES!
Decision Making: NOT swap
move LeftPointer to the right by 1

2nd PN, Round#4:
[6, 5, 2, 3, 5, 8, 9]
init Pointers:
PN =6
LN=5
RN =5

Qta?
1.] is LN > PN?
5 > 6?
NO!
2.] is RN < PN?
5 < 6 ?
YES!

Decision Making: NOT swap
move LeftPointer to the right by 1

2nd PN, Round#5:
[6, 5, 2, 3, 5, 8, 9]
init Pointers:
PN =6
LN=8
RN =5

because
LP>RP
swap pivotNum with the rightNum
we found the perfect position of the 2nd PivotNum
[5, 5, 2, 3,6,8,9]

find 3rdPivotNum --Round#1:
[5,5,2,3,6,8,9]
3rd PivotNum = 5

PN = 5
LN = 5
RN = 3

Qta:
LN > PN
5 >5?
NO!
RN < PN
3< 5
YES!
DO NOT SWAP
move leftpointer to the right

find 3rdPivotNum --Round#2:
[5,5,2,3,6,8,9]
3rd PivotNum = 5

PN = 5
LN = 2
RN = 3

Qta:
LN > PN
2 >5?
NO!
RN < PN
3< 5
YES!
DO NOT SWAP
move leftpointer to the right

find 3rdPivotNum --Round#3:
[5,5,2,3,6,8,9]
3rd PivotNum = 5

PN = 5
LN = 3
RN = 3

Qta:
LN > PN
3 >5?
NO!
RN < PN
3< 5
YES!
DO NOT SWAP
move leftpointer to the right

find 3rdPivotNum --Round#4:
Reach the exciting moment
since leftPointer > rightPointer,
we found the perfect position 3rd PivotNun
[5,5,2,3,6,8,9]
3rd PivotNum = 5

PN = 5
LN =6
RN = 3

decision making: swap
swap the pivotNum with rightNum
[3,5,2,5,6,8,9]

# PART.D: How to Approach this Question: --> Pseudo codes and Lay out Steps:

# PART.E: BIG O Notation Explainations

# PART.F: Alternative Solutions and Approaches

# PART. G: CheatSheet from last week session:

The different ways to write 'swap' function
Let's become 'Swap' Pro !!!!
a.] regular traditional way:
//helper function:
function swap(i, j, array){ // array[i] = 1, array[j] = 2
// save/store the value in variable to be future use/reference;
const temp = array[i];
array[i] = array[j];
//
array[j] = temp;//which is array[i]
}

b.] Devin's Modern Simplified 'swap' way:
function swap(i, j, array) {
// right side only cares about the left side; left side only cares about the right side.
[array[i], array[j]] = [array[j], array[i]];
}
